package com.mycompany.queuing_system;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;

public class Queuing_System {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
