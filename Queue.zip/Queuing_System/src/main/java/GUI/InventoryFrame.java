package GUI;

import java.awt.FlowLayout;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;

public class InventoryFrame extends javax.swing.JFrame {

    private Connection connection;
    String user = SelectTransactionFrame.activeUser;

    public InventoryFrame() {
        initComponents();
        loadTableProducts();
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/coffee_db", "root", "");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        //Bar graph
        Map<String, Integer> productSales = fetchProductSalesFromDatabase();
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        for (Map.Entry<String, Integer> entry : productSales.entrySet()) {
            dataset.addValue(entry.getValue(), "Sales", entry.getKey());
        }
        JFreeChart chart = ChartFactory.createBarChart(
                "Product Sales", // Chart title
                "Product Name", // X-axis label
                "Sales", // Y-axis label
                dataset
        );

        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(560, 320));

        // Add chart panel to analytics_panel
        analytics_panel.setLayout(new FlowLayout());
        analytics_panel.add(chartPanel);

        //Timestamp
        DefaultCategoryDataset stamp = fetchStampDataFromDatabase();
        JFreeChart stamp_chart = ChartFactory.createLineChart(
                "Product Sales Over Time", // Chart title
                "Time", // X-axis label
                "Sales", // Y-axis label
                stamp
        );

        ChartPanel stampPanel = new ChartPanel(stamp_chart);
        stampPanel.setPreferredSize(new java.awt.Dimension(560, 320));

        // Add stamp panel to timestamp_panel
        timestamp_panel.setLayout(new FlowLayout());
        timestamp_panel.add(stampPanel);
    }

    private Map<String, Integer> fetchProductSalesFromDatabase() {
        Map<String, Integer> productSales = new HashMap<>();
        try {
            String query = "SELECT product_name, SUM(product_quantity) as sales from purchased_logs GROUP BY product_name";
            PreparedStatement pst = connection.prepareStatement(query);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                String product = rs.getString("product_name");
                int quantity = rs.getInt("sales");
                productSales.put(product, quantity);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return productSales;
    }

    private DefaultCategoryDataset fetchStampDataFromDatabase() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        try {
            // Query to retrieve sales data from purchased_logs table
            String query = "SELECT timestamp_column, SUM(product_quantity) AS total_sales "
                    + "FROM purchased_logs "
                    + "GROUP BY timestamp_column";

            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            // Process the result set
            while (resultSet.next()) {
                Timestamp timestamp = resultSet.getTimestamp("timestamp_column");
                int totalSales = resultSet.getInt("total_sales");

                // Format the timestamp to your desired format
                String formattedTimestamp = formatTimestamp(timestamp);

                // Add data to the dataset
                dataset.addValue(totalSales, "Sales", formattedTimestamp);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return dataset;
    }

    private String formatTimestamp(Timestamp timestamp) {
        LocalDateTime dateTime = timestamp.toLocalDateTime();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return dateTime.format(formatter);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        analytics_panel = new javax.swing.JPanel();
        timestamp_panel = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        product_list = new javax.swing.JTable();
        jPanel10 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("CHN Cafe - Inventory/Analytics");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        analytics_panel.setBackground(new java.awt.Color(255, 255, 255));
        analytics_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(analytics_panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 20, 560, 300));

        timestamp_panel.setBackground(new java.awt.Color(255, 255, 255));
        timestamp_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(timestamp_panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 530, 300));

        jPanel1.add(jPanel2);

        jPanel3.add(jPanel4);

        jPanel1.add(jPanel3);

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 20, 40, 300));

        jPanel7.add(jPanel8);

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 30, 300));

        jPanel9.setBackground(new java.awt.Color(102, 102, 102));
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        product_list.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(product_list);

        jPanel9.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 510, 320));

        getContentPane().add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 350, 1110, 340));
        getContentPane().add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 690, 1150, 40));

        jPanel5.setBackground(new java.awt.Color(0, 0, 0));
        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1160, 30));

        jMenu1.setText("Options");

        jMenuItem2.setText("POS");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem1.setText("Log-out");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        int result = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Logout Confirmation", JOptionPane.YES_NO_OPTION);

        if (result == JOptionPane.YES_OPTION) {
            // Perform logout actions here
            System.out.println("Logging out...");
            LoginFrame lf = new LoginFrame();
            this.hide();
            lf.show();
        } else {
            // User chose No or closed the dialog
            System.out.println("Logout canceled.");
        }
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        SelectTransactionFrame stf = new SelectTransactionFrame(user);
        stf.show();
        this.hide();
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InventoryFrame().setVisible(true);
            }
        });
    }

private void loadTableProducts() {
        try {
            Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/coffee_db", "root", "");
            Statement st = connection.createStatement();
            String query = "SELECT product_name AS Product, product_price AS Price, product_quantity AS Quantity from products";
            ResultSet rs = st.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            DefaultTableModel model = (DefaultTableModel) product_list.getModel();
            model.setRowCount(0);
            int cols = rsmd.getColumnCount();
            String[] col_name = {"Product", "Price", "Quantity"};
            for (int i = 0; i < cols; i++) {
                col_name[i] = rsmd.getColumnName(i + 1);
                model.setColumnIdentifiers(col_name);
                String name, price, quantity;
                while (rs.next()) {
                    name = rs.getString("Product");
                    price = rs.getString("Price");
                    quantity = rs.getString("Quantity");
                    String[] row = {name, price, quantity};
                    model.addRow(row);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel analytics_panel;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable product_list;
    private javax.swing.JPanel timestamp_panel;
    // End of variables declaration//GEN-END:variables

}
