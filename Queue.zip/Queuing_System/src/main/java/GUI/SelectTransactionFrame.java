package GUI;

import java.awt.Component;
import java.util.List;
import java.sql.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.Timer;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.Element;

/**
 *
 * @author JHOY
 */
public class SelectTransactionFrame extends javax.swing.JFrame {

    private static List<String> rows;
    private int currentRow;
    private String timeInput, servingID;
    private String values;
    private DefaultTableModel tbl;
    private double total;
    private Map<Integer, Integer> deleteTimer;
    public static String activeUser;
    private int orderPunch;
    private double price;

    /**
     * Creates new form SelectTransactionFrame
     */
    public SelectTransactionFrame(String username) {
//        if(username.equals("client")){
//        Delete.setEnabled(false);
//        }else{
//        Delete.setEnabled(true);        
//        }

        this.activeUser = username;
        initComponents();
        loadBestSeller();
        userTag.setText(username);
        edit_logs.append("Order | Quantity | Total");
        loadTableProducts();
        OrderingTable();
        String checker = userTag.getText().trim();
        if (checker.equals("admin")) {
            inv.setEnabled(true);
        } else {
            inv.setEnabled(false);
        }

        //loadToDropDown(0);
        ListSelectionModel selectionModel = records_table.getSelectionModel();
        selectionModel.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    // Get the selected row and populate the text field with the value from the first column
                    int selectedRow = records_table.getSelectedRow();
                    if (selectedRow != -1) {
                        Object value = records_table.getValueAt(selectedRow, 0);
                        String p = String.valueOf(records_table.getValueAt(selectedRow, 1));
                        price = Double.parseDouble(p);
                        item_list.setText(value.toString());
                    }
                }
            }
        });
        Timer timer = new Timer(15000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeServing(servingID, timeInput);
            }
        });
        timer.start();
        cash.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                calculateChange();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                calculateChange();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                calculateChange();
            }

        });
    }

    private void calculateChange() {
        try {
            double inputValue = Integer.parseInt(cash.getText());
            double result = inputValue - total;
            change.setText(String.valueOf(result));

        } catch (NumberFormatException ex) {

        }
    }

    private void removePrepNum() {
        String prep = PreparingNum.getText();
        for (int i = PreparingOrder.getItemCount() - 1; i >= 0; i--) {
            String num = (String) PreparingOrder.getItemAt(i);
            if (prep.equals(num)) {
                PreparingOrder.removeItemAt(i);
                ServingOrder.addItem(prep);
            }
        }
    }

    private void loadTableProducts() {
        try {
            Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/coffee_db", "root", "");
            Statement st = connection.createStatement();
            String query = "SELECT product_name AS Product, product_price AS Price, product_quantity AS Quantity from products";
            ResultSet rs = st.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            DefaultTableModel model = (DefaultTableModel) records_table.getModel();
            model.setRowCount(0);
            int cols = rsmd.getColumnCount();
            String[] col_name = {"Product", "Price", "Quantity"};
            for (int i = 0; i < cols; i++) {
                col_name[i] = rsmd.getColumnName(i + 1);
                model.setColumnIdentifiers(col_name);
                String name, price, quantity;
                while (rs.next()) {
                    name = rs.getString("Product");
                    price = rs.getString("Price");
                    quantity = rs.getString("Quantity");
                    String[] row = {name, price, quantity};
                    model.addRow(row);
                }
            }
            model.setColumnIdentifiers(new Object[]{"Product", "Price","Quantity"});
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    private void loadBestSeller() {
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/coffee_db", "root", "");
            Statement st = connection.createStatement();
            String query = "SELECT product_name AS Product, SUM(product_quantity) AS Sales FROM purchased_logs GROUP BY product_name ORDER BY SUM(product_quantity) DESC LIMIT 10";
            ResultSet rs = st.executeQuery(query);

            DefaultTableModel model = (DefaultTableModel) best_seller.getModel();
            model.setRowCount(0);

            ResultSetMetaData rsmd = rs.getMetaData();
            int cols = rsmd.getColumnCount();
            String[] col_name = new String[cols];
            for (int i = 0; i < cols; i++) {
                col_name[i] = rsmd.getColumnName(i + 1);
            }
            model.setColumnIdentifiers(col_name);

            while (rs.next()) {
                String name = rs.getString("Product");
                int quantity = rs.getInt("Sales");
                String[] row = {name, String.valueOf(quantity)};
                model.addRow(row);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane4 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        order_table = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        records_table = new javax.swing.JTable();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        best_seller = new javax.swing.JTable();
        jLabel12 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        edit_logs = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        quantity = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        item_list = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        Delete = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        cash = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        change = new javax.swing.JTextField();
        userTag = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        PreparingNum = new javax.swing.JLabel();
        ServingNum = new javax.swing.JLabel();
        PreparingOrder = new javax.swing.JComboBox<>();
        PreparingInput = new javax.swing.JButton();
        PreparingSelect = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        ServingOrder = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        ServingInput = new javax.swing.JButton();
        ServingSelect = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        inv = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane4.setViewportView(jTable1);

        setTitle("CHN Cafe - POS");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        order_table.setBackground(new java.awt.Color(51, 51, 51));
        order_table.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        order_table.setForeground(new java.awt.Color(255, 255, 255));
        order_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Preparing", "Now Serving"
            }
        ));
        jScrollPane1.setViewportView(order_table);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 50, 660, 200));

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        records_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Product", "Price", "Quantity"
            }
        ));
        records_table.setRowHeight(30);
        jScrollPane2.setViewportView(records_table);

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("MENU");

        best_seller.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane5.setViewportView(best_seller);

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("BEST SELLER");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addContainerGap(16, Short.MAX_VALUE)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(207, 207, 207)
                        .addComponent(jLabel10)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel12)
                .addGap(170, 170, 170))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel12)
                .addGap(21, 21, 21)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(134, 134, 134))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 480, 490));

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));
        jPanel3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        edit_logs.setColumns(20);
        edit_logs.setRows(5);
        edit_logs.setAlignmentX(1.0F);
        edit_logs.setAlignmentY(1.0F);
        jScrollPane3.setViewportView(edit_logs);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("ORDERS");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 654, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(274, 274, 274))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(127, 127, 127))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 260, 660, 200));

        jPanel4.setBackground(new java.awt.Color(51, 51, 51));
        jPanel4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Product");

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Add");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        quantity.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        quantity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quantityActionPerformed(evt);
            }
        });

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Quantity");

        item_list.setEnabled(false);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(item_list)
                    .addComponent(quantity)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(item_list, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 550, 480, 150));

        jButton2.setBackground(new java.awt.Color(0, 0, 0));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Order Now");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 610, 150, 90));

        Delete.setText("Punch");
        Delete.setEnabled(false);
        Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteActionPerformed(evt);
            }
        });
        jPanel1.add(Delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 610, 150, 90));

        jPanel5.setBackground(new java.awt.Color(51, 51, 51));
        jPanel5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jButton3.setBackground(new java.awt.Color(102, 102, 102));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Add");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Cash Tendered");

        cash.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cash.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cashActionPerformed(evt);
            }
        });

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Change");

        change.setEditable(false);
        change.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        change.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                changeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(104, 104, 104)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(26, 26, 26)
                                .addComponent(change))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cash)))))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cash, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(change, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(28, 28, 28)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 610, 330, 90));

        userTag.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        userTag.setText("Serving: ");
        jPanel1.add(userTag, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 10, -1, -1));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel11.setText("Serving: ");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jPanel6.setBackground(new java.awt.Color(51, 51, 51));

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("No. of Preparing Order: ");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("PREPARING ORDER: ");

        PreparingNum.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        PreparingNum.setForeground(new java.awt.Color(255, 255, 255));

        ServingNum.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        ServingNum.setForeground(new java.awt.Color(255, 255, 255));

        PreparingOrder.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "110", "111", "112", "113", "114", "115", "116", "117", "118", "119", "120" }));
        PreparingOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PreparingOrderActionPerformed(evt);
            }
        });
        PreparingOrder.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                PreparingOrderPropertyChange(evt);
            }
        });

        PreparingInput.setText("Input");
        PreparingInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PreparingInputActionPerformed(evt);
            }
        });

        PreparingSelect.setText("Select");
        PreparingSelect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PreparingSelectActionPerformed(evt);
            }
        });

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("No. of Serving Order: ");

        ServingOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ServingOrderActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("SERVING ORDER: ");

        ServingInput.setText("Input");
        ServingInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ServingInputActionPerformed(evt);
            }
        });

        ServingSelect.setText("Select");
        ServingSelect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ServingSelectActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(PreparingOrder, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(PreparingNum, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(PreparingInput, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(PreparingSelect, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 179, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(ServingInput, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(ServingSelect, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(ServingNum, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(ServingOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(17, 17, 17))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(PreparingOrder, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(ServingOrder, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(PreparingNum, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ServingNum, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(PreparingSelect, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(PreparingInput, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ServingInput)
                            .addComponent(ServingSelect))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 470, 660, 130));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1180, 720));

        jMenu1.setText("Options");

        jMenuItem2.setText("Admin Access");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        inv.setText("Inventory");
        inv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                invActionPerformed(evt);
            }
        });
        jMenu1.add(inv);

        jMenuItem1.setText("Log-out");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void PreparingOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PreparingOrderActionPerformed

    }//GEN-LAST:event_PreparingOrderActionPerformed

    private void ServingOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ServingOrderActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ServingOrderActionPerformed

    private void PreparingSelectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PreparingSelectActionPerformed
        String selectedPreparingOrder = (String) PreparingOrder.getSelectedItem();
        PreparingNum.setText(selectedPreparingOrder);
        // TODO add your handling code here:
    }//GEN-LAST:event_PreparingSelectActionPerformed

    private void ServingSelectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ServingSelectActionPerformed
        String selectedServingOrder = (String) ServingOrder.getSelectedItem();
        ServingNum.setText(selectedServingOrder);
        // TODO add your handling code here:
    }//GEN-LAST:event_ServingSelectActionPerformed

    private void PreparingInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PreparingInputActionPerformed
        Delete.setEnabled(false);
        String userCash = cash.getText();
        double cc = Double.parseDouble(userCash);
        double px = cc - total;
        if (cash.getText().isEmpty() || cash.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "No tendered cash!");
        } else if (cc < total) {
            JOptionPane.showMessageDialog(null, "Insufficient Cash: " + px);
        } else {
            try {
                String prepNum = PreparingNum.getText();
                if (prepNum.equals("")) {
                    JOptionPane.showMessageDialog(null, "[INFO] No input found");
                } else {
                    Object[] rows = {prepNum, null};
                    tbl.addRow(rows);
                    removePrepNum();
                }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "[ERROR] No number to serve");
            }

            //File write
            String label = PreparingNum.getText();
            String content = edit_logs.getText();
            SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm a");
            Date now = new Date();
            String formattedTimestamp = dateFormat.format(now);
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("logs.txt", true))) {
                String msg;
                if (orderPunch == 1) {
                    msg = "[Punched]";
                } else {
                    msg = "[Not Punched]";
                }
                writer.write("[PREPARING]\n");
                writer.write("POS: " + activeUser + "\n");
                writer.write("Order Edited: " + msg + "\n");
                writer.write("Ordered by : " + formattedTimestamp + "\n");
                writer.write("Preparing Number: " + label + "\n");
                writer.write("Orders:----- \n" + content + "\n");
                writer.write("Cash Tendered: " + cash.getText() + "\n");
                writer.write("Change: " + change.getText() + "\n");
                writer.write("----------------------------------------\n");
            } catch (IOException e) {
                e.printStackTrace();
            }
            values = edit_logs.getText();
            PreparingNum.setText("");
            edit_logs.setText("");
            change.setText("");
            cash.setText("");
            orderPunch = 0;
            edit_logs.append("Order | Quantity | Total");
        }

    }//GEN-LAST:event_PreparingInputActionPerformed

    private void ServingInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ServingInputActionPerformed
        timeInput = JOptionPane.showInputDialog(this, "Enter serving time (in seconds):");
        try {
            servingID = (String) ServingOrder.getSelectedItem();
            if (servingID.equals("")) {
                JOptionPane.showMessageDialog(null, "[INFO] No input found");
            } else {
                Object[] rows = {null, servingID};

                for (int i = tbl.getRowCount() - 1; i >= 0; i--) {
                    Object val = tbl.getValueAt(i, 0);
                    if (val != null && val.toString().equals(servingID)) {
                        tbl.removeRow(i);
                        PreparingOrder.addItem(servingID);
                        ServingOrder.removeItem(servingID);
                        break;
                    }
                }

                tbl.addRow(rows);
            }

            String label = ServingNum.getText();
            String content = edit_logs.getText();
            SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm a");
            Date now = new Date();
            String formattedTimestamp = dateFormat.format(now);

            try (BufferedWriter writer = new BufferedWriter(new FileWriter("logs.txt", true))) {
                writer.write("[SERVING]\n");
                writer.write("POS: " + activeUser + "\n");
                writer.write("Serving Number: " + servingID + "\n");
                writer.write("Serving Time: " + formattedTimestamp + "\n");
                writer.write(values);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "[INNER]" + e);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "[OUTER]" + e);
        }
        ServingNum.setText("");

    }//GEN-LAST:event_ServingInputActionPerformed

    private void PreparingOrderPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_PreparingOrderPropertyChange

    }//GEN-LAST:event_PreparingOrderPropertyChange

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        int result = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Logout Confirmation", JOptionPane.YES_NO_OPTION);

        if (result == JOptionPane.YES_OPTION) {
            // Perform logout actions here
            System.out.println("Logging out...");
            LoginFrame lf = new LoginFrame();
            this.hide();
            lf.show();
        } else {
            // User chose No or closed the dialog
            System.out.println("Logout canceled.");
        }
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            String order_name = item_list.getText().toString();
            int qty = Integer.parseInt(quantity.getText());

            if (order_name.isEmpty() || order_name.equals("")) {
                JOptionPane.showMessageDialog(null, "Choose a product!");
            } else {

                double total = price * qty;
                edit_logs.append("\n" + order_name + " | " + qty + " | " + total);
                quantity.setText("");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Quantity is empty!");
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void quantityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quantityActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_quantityActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        String[] rows = edit_logs.getText().split("\n");
        double sum = 0;
        try (Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/coffee_db", "root", "")) {
            for (int i = 1; i < rows.length; i++) {
                String row = rows[i];
                String[] cols = row.split("\\|");
                if (cols.length >= 3) {
                    String name = cols[0];
                    int quantity = Integer.parseInt(cols[1].trim());
                    double value = Double.parseDouble(cols[2].trim());
                    sum += value;
                    int currentQuantity = getQuantity(connection, name);
                    if (currentQuantity >= quantity) {
                        // Subtract the desired quantity
                        int newQuantity = currentQuantity - quantity;
                        // Update the database with the new quantity
                        updateRecords(connection, name, newQuantity);
                        insertToLogs(connection, name, quantity);
                    } else {
                        System.out.println("Not enough quantity available for product: " + name);
                    }

                } else {
                    System.out.println("Invalid!");
                }
            }
            edit_logs.append("\n" + "--------------------------------");
            edit_logs.append("\n" + "------Thank you-----");
            edit_logs.append("\nTotal: " + sum);
            total = sum;
            generateReceipt(edit_logs.getText());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        loadTableProducts();

    }//GEN-LAST:event_jButton2ActionPerformed

    private void DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteActionPerformed

        deleteLastRow(edit_logs);           // TODO add your handling code here:
    }//GEN-LAST:event_DeleteActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void cashActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cashActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cashActionPerformed

    private void changeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_changeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_changeActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        String access = userTag.getText().trim();
        if (!access.equals("admin")) {
            String client_access = JOptionPane.showInputDialog(this, "Enter admin password to punch:");
            if (client_access.equals("adminpass")) {
                JOptionPane.showMessageDialog(null, "Allowed!");
                Delete.setEnabled(true);
                orderPunch = 1;
            } else {
                JOptionPane.showMessageDialog(null, "Not Allowed!");
            }
        } else {
            Delete.setEnabled(true);

        }
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void invActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_invActionPerformed
        InventoryFrame inv = new InventoryFrame();
        this.hide();
        inv.show();// TODO add your handling code here:
    }//GEN-LAST:event_invActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SelectTransactionFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SelectTransactionFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SelectTransactionFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SelectTransactionFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SelectTransactionFrame(activeUser).setVisible(true);

            }
        });
    }

    private void deleteLastRow(JTextArea textArea) {

        rows = new ArrayList<>(Arrays.asList(edit_logs.getText().split("\n")));
        currentRow = rows.size();
        if (!rows.isEmpty()) {
            rows.remove(rows.size() - 1);
            StringBuilder newText = new StringBuilder();
            for (String row : rows) {
                newText.append(row).append("\n");
            }
            textArea.setText(newText.toString().trim());
        }

    }

    private static void updateRecords(Connection connection, String productName, int quantity) throws SQLException {
        String sql = "UPDATE products SET product_quantity = ? WHERE product_name = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, quantity);
            statement.setString(2, productName);
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Updated product: " + productName);
            } else {
                System.out.println("Product not found: " + productName);
            }
        }
    }

    private static int getQuantity(Connection conn, String name) throws SQLException {
        String query = "SELECT product_quantity from products where product_name = ?";
        try (PreparedStatement pst = conn.prepareStatement(query)) {
            pst.setString(1, name);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("product_quantity");
                } else {
                    throw new SQLException("Product not found: " + name);
                }
            }
        }
    }

    private void removeServing(String id, String time) {
        for (int i = 0; i < tbl.getRowCount(); i++) {
            Object val = tbl.getValueAt(i, 1);
            if (val != null && !val.toString().isEmpty()) {
                String idx = id;
                String tx = time;

                if (servingID.equals(id)) { // Check if servingID matches user input
                    tbl.removeRow(i);
                    System.out.println("Serving : " + idx + " | Time:" + tx);
                }
            }
        }
    }

    private static void insertToLogs(Connection connection, String productName, int quantity) throws SQLException {
        String insertSql = "INSERT INTO purchased_logs (product_name, product_quantity) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(insertSql)) {
            statement.setString(1, productName);
            statement.setInt(2, quantity);
            statement.executeUpdate();
        }
    }

    private void OrderingTable() {
        tbl = new DefaultTableModel(new Object[]{"Preparing", "Now Serving"}, 0);
        order_table.setModel(tbl);
    }

    private void generateReceipt(String content) {
        // Define the directory path within the project
        String directoryPath = "receipts";

        // Create a File object representing the directory
        File directory = new File(directoryPath);

        // Check if the directory doesn't exist, create it
        if (!directory.exists()) {
            directory.mkdir(); // Create the directory
        }

        // Define the file name with a timestamp
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd-HHmmss");
        String timestamp = dateFormat.format(new Date());
        String fileName = "receipt_" + timestamp + ".txt";

        // Define the file path within the directory
        String filePath = directoryPath + "/" + fileName;

        // Define VAT rate
        double vatRate = 0.12; // 12% VAT assumed

        // Proceed to write the receipt file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            // Write the header
            writer.write("========================================\n");
            writer.write("                CHN CAFÉ                \n");
            writer.write("          Kapasigan, Pasig City         \n");
            writer.write("            TIN: 123-456-789            \n");
            writer.write("========================================\n");
            writer.write("         Order                Qty       \n");
            // Split the content into individual lines
            String[] lines = content.split("\n");
            double total = 0.0;

            // Process each line after the header
            for (int i = 1; i < lines.length; i++) {
                String line = lines[i];

                // Split each line into product name, quantity, and total
                String[] parts = line.split("\\|");

                // Check if the line has the expected number of parts
                if (parts.length == 3) {
                    String productName = parts[0].trim();
                    int quantity = Integer.parseInt(parts[1].trim());
                    double price = Double.parseDouble(parts[2].trim());

                    // Write product details to the receipt
                    writer.write(String.format("%-30s%-4d%.2f\n", productName, quantity, price));

                    // Update the total
                    total += price;
                } else {
                    System.err.println("Invalid line format: " + line);
                }
            }

            // Calculate VAT and subtotal
            double vatAmount = total * vatRate;
            double subtotal = total - vatAmount;

            // Write subtotal, VAT, and total
            writer.write("----------------------------------------\n");
            writer.write(String.format("%-30s%.2f\n", "Subtotal:", subtotal));
            writer.write(String.format("%-30s%.2f\n", "VAT (" + (vatRate * 100) + "%):", vatAmount));
            writer.write(String.format("%-30s%.2f\n", "Total:", total));
            writer.write("========================================\n");

            System.out.println("Receipt generated successfully!");
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Error generating receipt: " + e.getMessage());
        } catch (NumberFormatException e) {
            e.printStackTrace();
            System.err.println("Error parsing number: " + e.getMessage());
        }
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Delete;
    private javax.swing.JButton PreparingInput;
    private javax.swing.JLabel PreparingNum;
    private javax.swing.JComboBox<String> PreparingOrder;
    private javax.swing.JButton PreparingSelect;
    private javax.swing.JButton ServingInput;
    private javax.swing.JLabel ServingNum;
    private javax.swing.JComboBox<String> ServingOrder;
    private javax.swing.JButton ServingSelect;
    private javax.swing.JTable best_seller;
    private javax.swing.JTextField cash;
    private javax.swing.JTextField change;
    private javax.swing.JTextArea edit_logs;
    private javax.swing.JMenuItem inv;
    private javax.swing.JTextField item_list;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable order_table;
    private javax.swing.JTextField quantity;
    private javax.swing.JTable records_table;
    private javax.swing.JLabel userTag;
    // End of variables declaration//GEN-END:variables
}
